'use strict';
(() => {
  const mobileToggle = document.querySelector('.mobile-menu-toggle');
  const mobileNav = document.getElementById('mobile-nav');
  function setMobileNav(open) {
    if (!mobileNav || !mobileToggle) return;
    mobileNav.hidden = !open;
    mobileToggle.setAttribute('aria-expanded', String(open));
    mobileToggle.setAttribute('aria-label', open ? 'Закрыть меню' : 'Открыть меню');
  }
  mobileToggle?.addEventListener('click', () => setMobileNav(mobileNav.hidden));
  mobileNav?.querySelectorAll('a').forEach(link => link.addEventListener('click', () => setMobileNav(false)));
  document.addEventListener('keydown', e => { if (e.key === 'Escape') setMobileNav(false); });
  document.addEventListener('click', e => {
    if (mobileNav && !mobileNav.hidden && !mobileNav.contains(e.target) && !mobileToggle?.contains(e.target)) setMobileNav(false);
  });

  const dialog = document.getElementById('request-dialog');
  const openButtons = document.querySelectorAll('[data-open-request]');
  function openRequest() {
    if (!dialog) return;
    setMobileNav(false);
    if (typeof dialog.showModal === 'function') dialog.showModal();
    else dialog.setAttribute('open', '');
    dialog.querySelector('input[name="name"]')?.focus();
  }
  openButtons.forEach(el => el.addEventListener('click', openRequest));
  document.querySelector('[data-close-dialog]')?.addEventListener('click', () => dialog.close());
  dialog?.addEventListener('click', e => {
    const rect = dialog.getBoundingClientRect();
    if (e.clientX < rect.left || e.clientX > rect.right || e.clientY < rect.top || e.clientY > rect.bottom) dialog.close();
  });

  const form = document.getElementById('request-form');
  const errorLabel = document.getElementById('form-error');
  let copyButton;
  function fail(message) { if (!errorLabel) return; errorLabel.hidden = false; errorLabel.textContent = message; }
  form?.addEventListener('submit', async e => {
    e.preventDefault();
    if (errorLabel) { errorLabel.hidden = true; errorLabel.textContent = ''; }
    const name = form.elements.name.value.trim().replace(/[\r\n]+/g, ' ').slice(0, 80);
    const phone = form.elements.phone.value.trim().replace(/[\r\n]+/g, ' ');
    const digits = phone.replace(/\D/g, '');
    const comment = form.elements.comment.value.trim().slice(0, 500);
    if (digits.length < 10 || digits.length > 15) { fail('Проверьте номер телефона: нужно от 10 до 15 цифр.'); form.elements.phone.focus(); return; }
    if (!form.elements.consent.checked) { fail('Подтвердите согласие на использование данных для заявки.'); return; }
    const subject = 'Заявка на бесплатный замер — HomeDecor';
    const body = ['Здравствуйте! Хочу заказать бесплатный замер.', '', `Имя: ${name || 'Не указано'}`, `Телефон: ${phone}`, `Комментарий: ${comment || 'Не указан'}`, '', 'Отправлено с формы сайта HomeDecor.'].join('\n');
    const url = `mailto:hodecor@mail.ru?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    // mailto не подтверждает отправку. Не показываем ложное сообщение об успехе.
    window.location.href = url;
    if (!copyButton) {
      copyButton = document.createElement('button');
      copyButton.type = 'button';
      copyButton.className = 'button button-outline full';
      copyButton.textContent = 'Скопировать текст заявки';
      form.append(copyButton);
    }
    copyButton.onclick = async () => {
      try { await navigator.clipboard.writeText(`${subject}\n\n${body}`); copyButton.textContent = 'Текст скопирован ✓'; }
      catch { window.prompt('Скопируйте текст заявки:', `${subject}\n\n${body}`); }
    };
    fail('Откройте почтовую программу и нажмите «Отправить». Если почта не открылась, используйте кнопку копирования ниже или позвоните нам.');
  });

  document.getElementById('copyright-year')?.replaceChildren(document.createTextNode(String(new Date().getFullYear())));

  const detail = document.getElementById('product-detail');
  if (detail) {
    const slug = new URLSearchParams(window.location.search).get('type') || 'roller';
    const products = [
      ['roller','Рулонные шторы','Современный дизайн и функциональность','category-01.webp','Для спальни, кухни и гостиной'],
      ['horizontal','Горизонтальные жалюзи','Классика, проверенная временем','category-02.webp','Для дома и офиса'],
      ['vertical','Вертикальные жалюзи','Для больших окон и офисных помещений','category-03.webp','Точные настройки освещения'],
      ['valance','Вальс','Эстетика и изысканный дизайн','category-04.webp','Мягкие текстильные решения'],
      ['roman','Римские шторы','Уют и натуральные материалы','category-05.webp','Текстиль для вашего интерьера'],
      ['pleated','Плиссе','Эстетичное решение для нестандартных форм','category-06.webp','В том числе для сложных окон'],
      ['skylight','Для мансардных окон','Идеальное решение для крыши','category-07.webp','Окна под наклоном'],
      ['motor','Моторизация','Удобное управление одним нажатием','category-08.webp','Автоматизация оконных систем'],
      ['outdoor','Уличные жалюзи','Надёжная защита от солнца и непогоды','category-09.webp','Для террас и открытых пространств'],
      ['motor-curtains','Моторизованные шторные карнизы','Одно нажатие — и шторы движутся сами','category-10.webp','Тихое и комфортное управление'],
      ['mirage','Мираж','Лёгкость, свет и приватность','category-11.webp','Мягкая регулировка света'],
      ['photo','Фотопечать','Индивидуальный дизайн под ваш стиль','category-12.webp','Для индивидуальных проектов']
    ];
    const selected = products.find(item => item[0] === slug) || products[0];
    document.getElementById('detail-title').textContent = selected[1];
    document.getElementById('crumb-name').textContent = selected[1];
    document.getElementById('detail-description').textContent = `${selected[2]}. ${selected[4]}. Поможем подобрать материал, управление и подходящую комплектацию.`;
    const img = document.getElementById('detail-image');
    img.src = `assets/${selected[3]}`; img.alt = selected[1];
    document.title = `${selected[1]} на заказ — HomeDecor`;
  }
})();
